# students > 2024-03-14 1:53pm
https://universe.roboflow.com/yolo-workspace-v7abw/students-qamzm

Provided by a Roboflow user
License: CC BY 4.0

